define(function (require) {
  require('plugins/kibana-autocomplete-agency-plugin/autocomplete-agency.less');
  require('plugins/kibana-autocomplete-agency-plugin/autocompleteAgencyController');
  require('ui/registry/vis_types').register(AutocompleteAgencyVisProvider);

  function AutocompleteAgencyVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'autocomplete-agency',
      title: 'Agency filter',
	description: 'Allow to filter on agency with OR filter.',
	icon: 'fa-cogs',
      template: require('plugins/kibana-autocomplete-agency-plugin/autocomplete-agency.html'),
      params: {
        editor: require('plugins/kibana-autocomplete-agency-plugin/autocompleteAgencyOptions.html')
      },
      requiresSearch: false
    });
  }

  return AutocompleteAgencyVisProvider;
});
