
define(function (require) {
  var module = require('ui/modules').get('kibana/kibana-autocomplete-agency-plugin', ['kibana']);
  module.controller('KbnAutocompleteAgencyVisController', function ($scope, $rootScope, $filter, $http, Private) {
    var angular = require('angular');
    var filterManager = Private(require('ui/filter_manager'));
    $rootScope.plugin = {
      autocompleteAgencyPlugin: {}
    };
    $scope.founded_agencies = []
    $scope.searchAgency = function(){
      if ( $("#autocomplete-agency").val().length >= 3 ){
        $scope.founded_agencies = []
        $.ajax({
          url: "http://www.jerevedunemaison.com/agencies/autocompletion.json?term="+$("#autocomplete-agency").val(),
            success: function (response) {
            for (item in response){
              $scope.founded_agencies.push(response[item])
            }
          }
        });
      }
    }
      
      $scope.changeAgencyFilter = function(name){
	  agency_name = name;
	  if ( filterManager.filterAlreadyExist("agency_name") ){
              filterManager.addOrFilter("agency_name", agency_name)
	  }
	  else {
              filterManager.add("agency_name", agency_name, null, "houses");
	  }
	  $scope.founded_agencies = []
      }
      
      $scope.config = {};
      
      $scope.oldValue = null;
  });
});
