define(function (require) {
  require('plugins/kibana-autocomplete-cities-plugin/autocomplete-cities.less');
  require('plugins/kibana-autocomplete-cities-plugin/autocompleteCitiesController');
  require('ui/registry/vis_types').register(AutocompleteCitiesVisProvider);

  function AutocompleteCitiesVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'autocomplete-cities',
      title: 'Cities Filter',
      icon: 'fa-building',
      description: 'Allow to filter on regions, department, terroirs or cities.',
      template: require('plugins/kibana-autocomplete-cities-plugin/autocomplete-cities.html'),
      params: {
        editor: require('plugins/kibana-autocomplete-cities-plugin/autocompleteCitiesOptions.html')
      },
      requiresSearch: false
    });
  }

  return AutocompleteCitiesVisProvider;
});
