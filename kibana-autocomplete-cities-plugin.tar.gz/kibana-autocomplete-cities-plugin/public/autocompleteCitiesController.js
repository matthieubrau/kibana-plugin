define(function (require) {
    var module = require('ui/modules').get('kibana/kibana-autocomplete-cities-plugin', ['kibana']);
    module.controller('KbnAutocompleteCitiesVisController', function ($scope, $rootScope, $filter, $http, Private) {
	var angular = require('angular');
	var filterManager = Private(require('ui/filter_manager'));
	var self = this;
	// $rootScope.plugin = {
	//     autocompleteCitiesPlugin: {};
	// };
	
	// Tous les liens pour l'autocompletion.
	var url_region = "http://www.jerevedunemaison.com/regions/autocompletion.json?term=";
	var url_department = "http://www.jerevedunemaison.com/departments/autocompletion.json?term=";
	var url_natural_region = "http://www.jerevedunemaison.com/natural_regions/autocompletion.json?term=";
	var url_city = "http://www.jerevedunemaison.com/cities/autocompletion.json?term=";
	var url_dpt_by_region = "http://www.jerevedunemaison.com/departments/autocompletion_by_region_codes.json?region_codes=";
	var url_nat_region_by_region = "http://www.jerevedunemaison.com/natural_regions/autocompletion_by_region_codes.json?region_codes=";
	var url_nat_region_by_dpt = "http://www.jerevedunemaison.com/natural_regions/autocompletion_by_department_codes.json?department_code=";
	var url_city_by_region = "http://www.jerevedunemaison.com/cities/autocompletion_by_department_codes.json?region_codes=";
	var url_city_by_dpt = "http://www.jerevedunemaison.com/cities/autocompletion_by_department_codes.json?department_codes=";
	var url_city_by_nat_region = "http://www.jerevedunemaison.com/cities/autocompletion_by_department_codes.json?natural_region_codes=";

	
	$scope.founded_regions = [];
	$scope.founded_dpts = [];
	$scope.founded_nat_regions = [];
	$scope.founded_cities = [];

	$scope.selected_regions = [];
	$scope.selected_dpts = [];
	$scope.selected_nat_regions = [];

	$scope.dispScope = function() {
	    $scope.founded_regions = [];
	    $scope.founded_dpts = [];
	    $scope.founded_nat_regions = [];
	    $scope.founded_cities = [];
	    // $scope.autocomplete_region = '';
	    // $scope.autocomplete_department = '';
	    // $scope.autocomplete_nat_region = '';
	    // $scope.autocomplete_city = '';
	    // console.log($scope);
	};
	
	// Search functions
	$scope.searchRegions = function() {
	    if ($("#autocomplete_region").val().length >= 3) {
		$http.get(url_region+$("#autocomplete_region").val()).success(function (data) {
		    $scope.founded_regions = data;
		});
	    }
	};
	
	$scope.searchDepartments = function() {
	    if ($("#autocomplete_department").val().length >= 3) {
		console.log($scope.selected_regions.id);
		if ($scope.selected_regions.length > 0) {
		    var id = [];
		    id = $scope.selected_regions.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_dpt_by_region+id.join(",")+"&term="+$("#autocomplete_department")
			      .val()).success(function (data) {
				  $scope.founded_dpts = data;
			      });
		}
		else {
		    $http.get(url_department+$("#autocomplete_department").val()).success(function (data) {
			$scope.founded_dpts = data;
		    });
		}
	    }
	};

	$scope.searchNaturalRegions = function() {
	    if ($("#autocomplete_nat_region").val().length >= 3) {
		if ($scope.selected_dpts.length > 0) {
		    var id = [];
		    id = $scope.selected_dpts.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_nat_region_by_dpt+id.join(",")+"&term="+$("#autocomplete_nat_region")
			      .val()).success(function (data) {
				  $scope.founded_nat_regions = data;
			      });
		}
		else if ($scope.selected_regions.length > 0){
		    var id = [];
		    id = $scope.selected_regions.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_nat_region_by_region+id.join(",")+"&term="+$("#autocomplete_nat_region")
			      .val()).success(function (data) {
				  $scope.founded_nat_regions = data;
			      });
		}
		else {
		    $http.get(url_natural_region+$("#autocomplete_nat_region").val()).success(function (data) {
			$scope.founded_nat_regions = data;
		    });		    
		}
	    }
	}
	
	$scope.searchCities = function() {
	    if ($("#autocomplete_city").val().length >= 3) {
		if ($scope.selected_nat_regions.length > 0){
		    var id = [];
		    id = $scope.selected_nat_regions.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_city_by_nat_region+id.join(",")+"&term="+$("#autocomplete_city")
			      .val()).success(function (data) {
				  $scope.founded_cities = data;
			      });
		}
		else if ($scope.selected_dpts.length > 0) {
		    var id = [];
		    id = $scope.selected_dpts.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_city_by_dpt+id.join(",")+"&term="+$("#autocomplete_city")
			      .val()).success(function (data) {
				  $scope.founded_cities = data;
			      });
		}
		else if ($scope.selected_regions.length > 0){
		    var id = [];
		    id = $scope.selected_regions.map(function(obj) {
			return obj.id;
		    });
		    $http.get(url_city_by_region+id.join(",")+"&term="+$("#autocomplete_city")
			      .val()).success(function (data) {
				  $scope.founded_cities = data;
			      });
		}
		else {
		    $http.get(url_city+$("#autocomplete_city").val()).success(function (data) {
			$scope.founded_cities = data;
		    });
		}
	    }
	};

	// Select functions
	$scope.selectRegion = function(index) {
	    $scope.selected_regions.push($scope.founded_regions[index]);
	    $scope.founded_regions = [];
	    $scope.autocomplete_region = '';
	};

	$scope.selectDepartment = function(index) {
	    $scope.selected_dpts.push($scope.founded_dpts[index]);
	    $scope.founded_dpts = [];
	    $scope.autocomplete_department = '';
	};
	
	$scope.selectNaturalRegion = function(index) {
	    $scope.selected_nat_region.push($scope.founded_nat_regions[index]);
	    $scope.founded_nat_regions = [];
	    $scope.autocomplete_nat_region = '';
	};
	
	// Unselect functions
	$scope.unselectRegion = function(index) {
	    $scope.selected_regions.splice(index, 1);
	};

	$scope.unselectDepartment = function(index) {
	    $scope.selected_dpts.splice(index, 1);
	};
	
	$scope.unselectNaturalRegion = function(index) {
	    $scope.selected_nat_region.splice(index, 1);
	};
	
	// add filter function
	$scope.addFilter = function (field, value) {
	    if (filterManager.getAll().length != 0) {
		filterManager.addOrFilter(field, value)
	    }
	     else {
	    	 filterManager.add(field, value, null, "houses");
	     }
	   // if ( filterManager.filterAlreadyExist(field) ){

	   //  }
	   //  }
	    if (field == "city_name") {
		$scope.founded_cities = [];
		$scope.autocomplete_city = '';
	    }
	}
    });
});
