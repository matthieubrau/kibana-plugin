
define(function (require) {
  var module = require('ui/modules').get('kibana/kibana-autocomplete-scrap-plugin', ['kibana']);
  module.controller('KbnAutocompleteScrapVisController', function ($scope, $rootScope, $filter, $http, Private) {
    var angular = require('angular');
    var filterManager = Private(require('ui/filter_manager'));
    $rootScope.plugin = {
      autocompleteScrapPlugin: {}
    };
    $scope.founded_scraps = []
    $scope.searchScrap = function(){
      if ( $("#autocomplete-scrap").val().length >= 3 ){
        $scope.founded_scraps = []
        $.ajax({
          url: "http://www.jerevedunemaison.com/scraps/autocompletion.json?term="+$("#autocomplete-scrap").val(),
            success: function (response) {
            for (item in response){
              $scope.founded_scraps.push(response[item])
            }
          }
        });
      }
    }
      
      $scope.changeScrapFilter = function(name){
	  scrap_name = name;
	  if ( filterManager.filterAlreadyExist("classified_scrap_names") ){
              filterManager.addOrFilter("classified_scrap_names", scrap_name)
	  }
	  else {
              filterManager.add("classified_scrap_names", scrap_name, null, "houses");
	  }
	  $scope.founded_scraps = []
      }
      
      $scope.config = {};
      
      $scope.oldValue = null;
  });
});
