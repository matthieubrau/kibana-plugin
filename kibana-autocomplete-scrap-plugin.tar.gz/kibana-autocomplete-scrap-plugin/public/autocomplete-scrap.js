define(function (require) {
  require('plugins/kibana-autocomplete-scrap-plugin/autocomplete-scrap.less');
  require('plugins/kibana-autocomplete-scrap-plugin/autocompleteScrapController');
  require('ui/registry/vis_types').register(AutocompleteScrapVisProvider);

  function AutocompleteScrapVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'autocomplete-scrap',
      title: 'Scrap filter',
	description: 'Allow to filter on scrap with OR filter',
	icon: 'fa-database',
      template: require('plugins/kibana-autocomplete-scrap-plugin/autocomplete-scrap.html'),
      params: {
        editor: require('plugins/kibana-autocomplete-scrap-plugin/autocompleteScrapOptions.html')
      },
      requiresSearch: false
    });
  }

  return AutocompleteScrapVisProvider;
});
