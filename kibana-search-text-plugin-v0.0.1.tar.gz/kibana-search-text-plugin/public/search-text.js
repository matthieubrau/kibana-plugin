define(function (require) {
  require('plugins/kibana-search-text-plugin/search-text.less');
  require('plugins/kibana-search-text-plugin/searchTextController');
  require('ui/registry/vis_types').register(SearchTextVisProvider);

  function SearchTextVisProvider(Private) {
    var TemplateVisType = Private(require('ui/template_vis_type/TemplateVisType'));

    return new TemplateVisType({
      name: 'search-text',
      title: 'Text Filter',
      icon: 'fa-cog',
      description: 'Allow to filter on texts by using operator formula',
      template: require('plugins/kibana-search-text-plugin/search-text.html'),
      params: {
        editor: require('plugins/kibana-search-text-plugin/searchTextOptions.html')
      },
      requiresSearch: false
    });
  }

  return SearchTextVisProvider;
});
