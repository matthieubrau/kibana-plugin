define(function (require) {
  var module = require('ui/modules').get('kibana/kibana-search-text-plugin', ['kibana']);
  module.controller('KbnSearchTextVisController', function ($scope, $rootScope, $filter, $http, Private) {
    var angular = require('angular');
    var filterManager = Private(require('ui/filter_manager'));
    var self = this
    $rootScope.plugin = {
      searchTextPlugin: {}
    };

    $scope.selected_words = []
    $scope.selected_words_and = []
    $scope.selected_words_or = []
    $scope.selected_words_nor = []

    window.drop = function(e){
      e.preventDefault();
      var data = e.dataTransfer.getData("text");
      var key = parseInt(data.split("-")[1])
      var type = data.split("-")[0]

      var item = self.getItemByTypeByKey(type, key)

      if ( $(e.target).hasClass("and") ){
        if ( self.itemExist($scope.selected_words_and, item) == false ){
          $scope.selected_words_and.push(item)
        }
      }else if ( $(e.target).hasClass("or") ){
        if ( self.itemExist($scope.selected_words_or, item) == false ){
          $scope.selected_words_or.push(item)
        }
      }else if ( $(e.target).hasClass("nor") ){
        if ( self.itemExist($scope.selected_words_nor, item) == false ){
          $scope.selected_words_nor.push(item)
        }
      }else{
        if ( self.itemExist($scope.selected_words, item) == false ){
          $scope.selected_words.push(item)
        }
      }
    }
    window.allowDrop = function(e){
      e.preventDefault();
    }
    window.drag = function(e){
      e.dataTransfer.setData("text", e.target.id);
    }

    $scope.addWord = function(){
      word = {label: $("#search-text").val()}
      if ( self.itemExist($scope.selected_words, word) == false ){
        $scope.selected_words.push(word)
      }
    }

    self.itemExist = function(itemList, item){
      exist = false
      for (j = 0; j < itemList.length; j++){
        if ( itemList[j].label == item.label ){
          return true
        }
      }
      return false
    }

    $scope.unselectWord = function(index){
      $scope.selected_words.splice(index, 1);
    }
    $scope.unselectWordOr = function(index){
      $scope.selected_words_or.splice(index, 1);
    }
    $scope.unselectWordAnd = function(index){
      $scope.selected_words_and.splice(index, 1);
    }
    $scope.unselectWordNor = function(index){
      $scope.selected_words_nor.splice(index, 1);
    }


    $scope.addWordsToFilter = function(){
      if ( words_filter = filterManager.filterAlreadyExist("description") ){
        if (confirm("Vous allez supprimer le filtre description courant")){
          filterManager.removeOperatorFilter(words_filter)
        }
      }
      filterManager.add("description", $scope.selected_words[0].label, null, "houses").then(function(){
        for (var i = 1; i < $scope.selected_words.length; i++ ){
          label = $scope.selected_words[i].label
          filterManager.addOrFilter("description", label)
        }
      })
    }

    $scope.addFormulaWordToFilter = function(){
      if ( words_filter = filterManager.filterAlreadyExist("description") ){
        if (confirm("Vous allez supprimer le filtre description courant") == true){
          filterManager.removeOperatorFilter(words_filter)
        }
      }
      var i_and_start = 0
      var i_or_start = 0
      var i_nor_start = 0
      var operator_first_word_filter = ""

      if ( $scope.selected_words_and.length > 0){
        var first_filter = filterManager.add("description", $scope.selected_words_and[0].label, null, "houses")
        i_and_start = 1
        operator_first_word_filter = "must"
      }else if ( $scope.selected_words_or.length > 0){
        var first_filter = filterManager.add("description", $scope.selected_words_or[0].label, null, "houses")
        i_or_start = 1
        operator_first_word_filter = "should"
      }else if ( $scope.selected_words_nor.length > 0){
        var first_filter = filterManager.add("description", $scope.selected_words_nor[0].label, null, "houses")
        i_nor_start = 1
        operator_first_word_filter = "must_not"
      }

      first_filter.then(function(){
        for (var i = i_and_start; i < $scope.selected_words_and.length; i++ ){
          label = $scope.selected_words_and[i].label
          filterManager.addOperatorFilter("description", label, "must", operator_first_word_filter)
        }
        for (var i = i_or_start; i < $scope.selected_words_or.length; i++ ){
          label = $scope.selected_words_or[i].label
          filterManager.addOperatorFilter("description", label, "should", operator_first_word_filter)
        }
        for (var i = i_nor_start; i < $scope.selected_words_nor.length; i++ ){
          label = $scope.selected_words_nor[i].label
          filterManager.addOperatorFilter("description", label, "must_not", operator_first_word_filter)
        }
      })
    }

    self.getItemByTypeByKey = function(type, key){
      if ( type == "word" ){
        item = $scope.selected_words[key]
        $scope.selected_words.splice(key, 1)
      }else if (type == "wordand"){
        item = $scope.selected_words_and[key]
        $scope.selected_words_and.splice(key, 1)
      }else if (type == "wordor"){
        item = $scope.selected_words_or[key]
        $scope.selected_words_or.splice(key, 1)
      }else if (type == "wordnor"){
        item = $scope.selected_words_nor[key]
        $scope.selected_words_nor.splice(key, 1)
      }
      return item
    }

    self.initWordsList = function(){
      if ( words_filter = filterManager.filterAlreadyExist("description") ){
        if ( words_filter.bool ){
          if ( words_filter.bool.should ){
            for (var i=0; i< words_filter.bool.should.length; i++){
              $scope.selected_words_or.push({label: words_filter.bool.should[i].query.match.description.query})
            }
          }
          if ( words_filter.bool.must ){
            for (var i=0; i< words_filter.bool.must.length; i++){
              $scope.selected_words_and.push({label: words_filter.bool.must[i].query.match.description.query})
            }
          }
          if ( words_filter.bool.must_not ){
            for (var i=0; i< words_filter.bool.must_not.length; i++){
              $scope.selected_words_nor.push({label: words_filter.bool.must_not[i].query.match.description.query})
            }
          }
        }else{
          $scope.selected_words.push({label: words_filter.query.match.description.query})
        }
      }
    }
    self.initWordsList();
    $scope.config = {};

    $scope.oldValue = null;
  });
});
