# Kibana Autocomplete tags Plugin Widget
Autocomplete tags Plugin Widget for Kibana.

# Install

```bash
bin/kibana plugin -i kibana-autocomplete-tags-plugin -u https://github.com/matthieubrau/autocomplete-tags-kibana-plugin/raw/master/resources/kibana-autocomplete-tags-plugin-v.0.0.1.tar.gz
```

# Compatibility
Plugins are officialy not supported, because of fast code changes even in minor Versions.

The plugin is compatible with following Versions (other not tested yet):
* kibana (=4.x)

